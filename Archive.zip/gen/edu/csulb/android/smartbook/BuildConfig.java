/** Automatically generated file. DO NOT MODIFY */
package edu.csulb.android.smartbook;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}